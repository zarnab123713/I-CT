// Display welcome alert when the page loads
window.onload = function() {
    alert("Welcome to my portfolio!");
};

// Change background color when button is clicked
function changeBackground() {
    document.body.style.backgroundColor = "#add8e6";
}

// Form validation
document.getElementById("contactForm").addEventListener("submit", function(event) {
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;

    if (name === "" || email === "") {
        alert("Please fill in all fields.");
        event.preventDefault();
    }else if(!email.match(emailPattern)){
    alert("Please enter a valid email address.");
    event.preventDefault();
}
});
function name() {
    document.body.style.backgroundcolor="#add8e6";
}changeBackground
